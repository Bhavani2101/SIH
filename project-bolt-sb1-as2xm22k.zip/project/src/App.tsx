import React, { useState, useEffect } from 'react';
import { User, BookOpen, Users, BarChart3, Play, CheckCircle, Upload, Eye, Plus } from 'lucide-react';
import ClassUpload from './components/ClassUpload';

type UserRole = 'student' | 'teacher' | 'admin';

interface UserData {
  id: string;
  name: string;
  role: UserRole;
}

interface Class {
  id: string;
  title: string;
  subject: string;
  duration: string;
  completed: boolean;
  progress: number;
}

interface Quiz {
  id: string;
  title: string;
  subject: string;
  score?: number;
  totalQuestions: number;
}

function App() {
  const [currentUser, setCurrentUser] = useState<UserData | null>(null);
  const [currentPage, setCurrentPage] = useState<'home' | 'dashboard'>('home');
  const [showLogin, setShowLogin] = useState(true);
  const [showClassUpload, setShowClassUpload] = useState(false);
  const [uploadedClasses, setUploadedClasses] = useState<any[]>([]);

  // Sample data
  const classes: Class[] = [
    { id: '1', title: 'Basic Mathematics', subject: 'Math', duration: '45 min', completed: true, progress: 100 },
    { id: '2', title: 'English Grammar', subject: 'English', duration: '30 min', completed: false, progress: 60 },
    { id: '3', title: 'Science Basics', subject: 'Science', duration: '40 min', completed: false, progress: 25 },
  ];

  const quizzes: Quiz[] = [
    { id: '1', title: 'Math Quiz 1', subject: 'Math', score: 8, totalQuestions: 10 },
    { id: '2', title: 'English Test', subject: 'English', totalQuestions: 15 },
  ];

  const handleLogin = (role: UserRole) => {
    const userData: UserData = {
      id: '1',
      name: role === 'student' ? 'Priya Sharma' : role === 'teacher' ? 'Rajesh Kumar' : 'Admin User',
      role: role
    };
    setCurrentUser(userData);
    setCurrentPage('dashboard');
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setCurrentPage('home');
    setShowLogin(true);
  };

  const handleSaveClass = (classData: any) => {
    setUploadedClasses(prev => [...prev, classData]);
    setShowClassUpload(false);
    // Here you would typically send the data to your backend
    console.log('Class saved:', classData);
  };

  if (currentPage === 'home') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
        {/* Header */}
        <header className="bg-white shadow-sm">
          <div className="max-w-6xl mx-auto px-4 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <BookOpen className="w-8 h-8 text-blue-600" />
                <h1 className="text-xl font-bold text-gray-800">EduSmart</h1>
              </div>
            </div>
          </div>
        </header>

        {/* Hero Banner */}
        <div className="max-w-6xl mx-auto px-4 py-8">
          <div className="text-center mb-8">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">
              Smart Education for Rural Areas
            </h2>
            <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto">
              Access quality education anywhere, anytime. Designed for low internet connectivity and budget devices.
            </p>
          </div>

          {/* Login/Register Section */}
          <div className="bg-white rounded-lg shadow-md p-6 max-w-md mx-auto">
            <div className="flex mb-4">
              <button
                onClick={() => setShowLogin(true)}
                className={`flex-1 py-2 text-center font-medium rounded-l-lg ${
                  showLogin ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600'
                }`}
              >
                Login
              </button>
              <button
                onClick={() => setShowLogin(false)}
                className={`flex-1 py-2 text-center font-medium rounded-r-lg ${
                  !showLogin ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600'
                }`}
              >
                Register
              </button>
            </div>

            {showLogin ? (
              <div>
                <h3 className="text-xl font-semibold mb-4">Login as:</h3>
                <div className="space-y-3">
                  <button
                    onClick={() => handleLogin('student')}
                    className="w-full bg-green-500 hover:bg-green-600 text-white py-3 px-4 rounded-lg font-medium transition-colors flex items-center justify-center gap-2"
                  >
                    <User className="w-5 h-5" />
                    Student
                  </button>
                  <button
                    onClick={() => handleLogin('teacher')}
                    className="w-full bg-blue-500 hover:bg-blue-600 text-white py-3 px-4 rounded-lg font-medium transition-colors flex items-center justify-center gap-2"
                  >
                    <Users className="w-5 h-5" />
                    Teacher
                  </button>
                  <button
                    onClick={() => handleLogin('admin')}
                    className="w-full bg-purple-500 hover:bg-purple-600 text-white py-3 px-4 rounded-lg font-medium transition-colors flex items-center justify-center gap-2"
                  >
                    <BarChart3 className="w-5 h-5" />
                    Admin
                  </button>
                </div>
              </div>
            ) : (
              <div>
                <h3 className="text-xl font-semibold mb-4">Create Account</h3>
                <form className="space-y-4">
                  <input
                    type="text"
                    placeholder="Full Name"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                  <input
                    type="email"
                    placeholder="Email"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                  <select className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    <option>Select Role</option>
                    <option value="student">Student</option>
                    <option value="teacher">Teacher</option>
                  </select>
                  <input
                    type="password"
                    placeholder="Password"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                  <button
                    type="submit"
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-lg font-medium transition-colors"
                  >
                    Create Account
                  </button>
                </form>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  // Dashboard based on user role
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <BookOpen className="w-8 h-8 text-blue-600" />
              <h1 className="text-xl font-bold text-gray-800">EduSmart</h1>
            </div>
            <div className="flex items-center gap-4">
              <span className="text-sm text-gray-600">Welcome, {currentUser?.name}</span>
              <button
                onClick={handleLogout}
                className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg text-sm transition-colors"
              >
                Logout
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-4 py-6">
        {currentUser?.role === 'student' && (
          <div>
            <h2 className="text-2xl font-bold text-gray-800 mb-6">Student Dashboard</h2>
            
            {/* Progress Overview */}
            <div className="bg-white rounded-lg shadow-md p-6 mb-6">
              <h3 className="text-lg font-semibold mb-4">Your Progress</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center p-4 bg-blue-50 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">3</div>
                  <div className="text-sm text-gray-600">Total Classes</div>
                </div>
                <div className="text-center p-4 bg-green-50 rounded-lg">
                  <div className="text-2xl font-bold text-green-600">1</div>
                  <div className="text-sm text-gray-600">Completed</div>
                </div>
                <div className="text-center p-4 bg-orange-50 rounded-lg">
                  <div className="text-2xl font-bold text-orange-600">62%</div>
                  <div className="text-sm text-gray-600">Avg Progress</div>
                </div>
              </div>
            </div>

            {/* Classes List */}
            <div className="bg-white rounded-lg shadow-md p-6 mb-6">
              <h3 className="text-lg font-semibold mb-4">My Classes</h3>
              <div className="space-y-4">
                {classes.map((cls) => (
                  <div key={cls.id} className="border border-gray-200 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium text-gray-800">{cls.title}</h4>
                      <span className="text-sm text-gray-500">{cls.duration}</span>
                    </div>
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-sm text-blue-600">{cls.subject}</span>
                      {cls.completed && <CheckCircle className="w-5 h-5 text-green-500" />}
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2 mb-3">
                      <div 
                        className="bg-blue-600 h-2 rounded-full" 
                        style={{ width: `${cls.progress}%` }}
                      ></div>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">{cls.progress}% complete</span>
                      <button className="text-blue-600 hover:text-blue-700 flex items-center gap-1">
                        <Play className="w-4 h-4" />
                        {cls.completed ? 'Review' : 'Continue'}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Quizzes */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold mb-4">Quizzes</h3>
              <div className="space-y-4">
                {quizzes.map((quiz) => (
                  <div key={quiz.id} className="border border-gray-200 rounded-lg p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium text-gray-800">{quiz.title}</h4>
                        <span className="text-sm text-blue-600">{quiz.subject}</span>
                      </div>
                      <div className="text-right">
                        {quiz.score ? (
                          <div>
                            <div className="text-lg font-semibold text-green-600">
                              {quiz.score}/{quiz.totalQuestions}
                            </div>
                            <div className="text-sm text-gray-500">Completed</div>
                          </div>
                        ) : (
                          <button className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg text-sm transition-colors">
                            Take Quiz
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {currentUser?.role === 'teacher' && (
          <div>
            <h2 className="text-2xl font-bold text-gray-800 mb-6">Teacher Dashboard</h2>
            
            {showClassUpload && (
              <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
                <div className="max-w-4xl w-full max-h-[90vh] overflow-y-auto">
                  <ClassUpload
                    onSave={handleSaveClass}
                    onCancel={() => setShowClassUpload(false)}
                  />
                </div>
              </div>
            )}

            {/* Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
              <div className="bg-white p-6 rounded-lg shadow-md text-center">
                <div className="text-2xl font-bold text-blue-600">{5 + uploadedClasses.length}</div>
                <div className="text-sm text-gray-600">Total Classes</div>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md text-center">
                <div className="text-2xl font-bold text-green-600">24</div>
                <div className="text-sm text-gray-600">Active Students</div>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md text-center">
                <div className="text-2xl font-bold text-purple-600">3</div>
                <div className="text-sm text-gray-600">Quizzes Created</div>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md text-center">
                <div className="text-2xl font-bold text-orange-600">78%</div>
                <div className="text-sm text-gray-600">Avg Score</div>
              </div>
            </div>

            {/* Quick Upload Section */}
            <div className="bg-white rounded-lg shadow-md p-6 mb-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">Class Management</h3>
                <button
                  onClick={() => setShowClassUpload(true)}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition-colors flex items-center gap-2"
                >
                  <Plus className="w-4 h-4" />
                  Upload New Class
                </button>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center p-4 bg-blue-50 rounded-lg">
                  <Upload className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                  <h4 className="font-medium text-gray-800">Upload Content</h4>
                  <p className="text-sm text-gray-600">Videos, documents, images</p>
                </div>
                <div className="text-center p-4 bg-green-50 rounded-lg">
                  <BookOpen className="w-8 h-8 text-green-600 mx-auto mb-2" />
                  <h4 className="font-medium text-gray-800">Organize Classes</h4>
                  <p className="text-sm text-gray-600">Structure your curriculum</p>
                </div>
                <div className="text-center p-4 bg-purple-50 rounded-lg">
                  <BarChart3 className="w-8 h-8 text-purple-600 mx-auto mb-2" />
                  <h4 className="font-medium text-gray-800">Track Progress</h4>
                  <p className="text-sm text-gray-600">Monitor student engagement</p>
                </div>
              </div>
            </div>

            {/* Recently Uploaded Classes */}
            {uploadedClasses.length > 0 && (
              <div className="bg-white rounded-lg shadow-md p-6 mb-6">
                <h3 className="text-lg font-semibold mb-4">Recently Uploaded Classes</h3>
                <div className="space-y-3">
                  {uploadedClasses.slice(-3).map((cls, index) => (
                    <div key={index} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-medium text-gray-800">{cls.title}</h4>
                          <p className="text-sm text-blue-600">{cls.subject}</p>
                          <p className="text-xs text-gray-500">{cls.materials?.length || 0} materials uploaded</p>
                        </div>
                        <div className="text-right">
                          <span className="text-xs text-green-600 bg-green-100 px-2 py-1 rounded-full">
                            Published
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Upload Guidelines */}
            <div className="bg-white rounded-lg shadow-md p-6 mb-6">
              <h3 className="text-lg font-semibold mb-4">📱 Mobile-Friendly Upload Guidelines</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-medium text-gray-800 mb-2">Video Guidelines</h4>
                  <ul className="text-sm text-gray-600 space-y-1">
                    <li>• Maximum size: 50MB per video</li>
                    <li>• Recommended format: MP4</li>
                    <li>• Resolution: 720p or lower</li>
                    <li>• Duration: 5-15 minutes per segment</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-medium text-gray-800 mb-2">Document Guidelines</h4>
                  <ul className="text-sm text-gray-600 space-y-1">
                    <li>• Supported: PDF, DOC, PPT</li>
                    <li>• Maximum size: 10MB per file</li>
                    <li>• Use clear, readable fonts</li>
                    <li>• Include page numbers</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Student Progress */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold mb-4">Student Progress</h3>
              <div className="space-y-4">
                {[
                  { name: 'Priya Sharma', progress: 85, quizzes: 3, classes: 4 },
                  { name: 'Amit Kumar', progress: 72, quizzes: 2, classes: 3 },
                  { name: 'Sunita Singh', progress: 93, quizzes: 4, classes: 5 },
                ].map((student, index) => (
                  <div key={index} className="border border-gray-200 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium text-gray-800">{student.name}</h4>
                      <button className="text-blue-600 hover:text-blue-700">
                        <Eye className="w-4 h-4" />
                      </button>
                    </div>
                    <div className="grid grid-cols-3 gap-4 text-sm">
                      <div>
                        <div className="text-gray-600">Progress</div>
                        <div className="font-semibold">{student.progress}%</div>
                      </div>
                      <div>
                        <div className="text-gray-600">Quizzes</div>
                        <div className="font-semibold">{student.quizzes}</div>
                      </div>
                      <div>
                        <div className="text-gray-600">Classes</div>
                        <div className="font-semibold">{student.classes}</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {currentUser?.role === 'admin' && (
          <div>
            <h2 className="text-2xl font-bold text-gray-800 mb-6">Admin Dashboard</h2>
            
            {/* Overall Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
              <div className="bg-white p-6 rounded-lg shadow-md text-center">
                <div className="text-2xl font-bold text-blue-600">150</div>
                <div className="text-sm text-gray-600">Total Students</div>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md text-center">
                <div className="text-2xl font-bold text-green-600">12</div>
                <div className="text-sm text-gray-600">Teachers</div>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md text-center">
                <div className="text-2xl font-bold text-purple-600">45</div>
                <div className="text-sm text-gray-600">Total Classes</div>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md text-center">
                <div className="text-2xl font-bold text-orange-600">82%</div>
                <div className="text-sm text-gray-600">Completion Rate</div>
              </div>
            </div>

            {/* User Management */}
            <div className="bg-white rounded-lg shadow-md p-6 mb-6">
              <h3 className="text-lg font-semibold mb-4">Manage Users</h3>
              <div className="flex justify-between items-center mb-4">
                <input
                  type="text"
                  placeholder="Search users..."
                  className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors">
                  Add User
                </button>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-gray-200">
                      <th className="text-left py-2">Name</th>
                      <th className="text-left py-2">Role</th>
                      <th className="text-left py-2">Status</th>
                      <th className="text-left py-2">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      { name: 'Priya Sharma', role: 'Student', status: 'Active' },
                      { name: 'Rajesh Kumar', role: 'Teacher', status: 'Active' },
                      { name: 'Amit Singh', role: 'Student', status: 'Inactive' },
                    ].map((user, index) => (
                      <tr key={index} className="border-b border-gray-100">
                        <td className="py-2">{user.name}</td>
                        <td className="py-2">
                          <span className={`px-2 py-1 rounded-full text-xs ${
                            user.role === 'Teacher' ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800'
                          }`}>
                            {user.role}
                          </span>
                        </td>
                        <td className="py-2">
                          <span className={`px-2 py-1 rounded-full text-xs ${
                            user.status === 'Active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                          }`}>
                            {user.status}
                          </span>
                        </td>
                        <td className="py-2">
                          <button className="text-blue-600 hover:text-blue-700 text-xs mr-2">Edit</button>
                          <button className="text-red-600 hover:text-red-700 text-xs">Delete</button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Reports */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold mb-4">Reports</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 border border-gray-200 rounded-lg">
                  <h4 className="font-medium mb-2">Student Engagement</h4>
                  <div className="text-2xl font-bold text-blue-600 mb-1">78%</div>
                  <div className="text-sm text-gray-600">Average daily active users</div>
                </div>
                <div className="p-4 border border-gray-200 rounded-lg">
                  <h4 className="font-medium mb-2">Course Completion</h4>
                  <div className="text-2xl font-bold text-green-600 mb-1">65%</div>
                  <div className="text-sm text-gray-600">Students completing courses</div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;